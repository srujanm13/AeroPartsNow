package com.aeropartsnow.sampletests;



import static org.testng.Assert.assertTrue;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;


public class HomePageTestCase {

	@Test
	public static void verifyRFQcreation() throws InterruptedException{
		String env="https://aithinkers.uat.myaeropartsnow.com/admin";
		String uname="narendra.t@aithinkers.com";
		String pwd="Test@1234";
		System.out.println();
		System.setProperty("webdriver.chrome.driver", "\\src\\main\\resources\\browserexecutables\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.get(env);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.id("login_username")).sendKeys(uname);
		driver.findElement(By.id("login_password")).sendKeys(pwd);
		//closing Home Page New features Pop up
		Actions a=new Actions(driver);
		a.moveToElement(driver.findElement(By.xpath("//body/div[@id='beacon-container']/div[1]/div[1]/div[4]/iframe[1]"))).build().perform();
		driver.switchTo().frame(3);
		a.click(driver.findElement(By.cssSelector(".Textcss__TextUI-cdrlb6-0"))).build().perform();
		a.release();
		//Signing in 
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/section/section/div/div/form/button")).click();
		//Click on RFQ
		driver.findElement(By.xpath("//body/div[@id='root']/div[1]/div[1]/section[1]/section[1]/aside[1]/div[1]/ul[1]/li[5]")).click();
		driver.switchTo().parentFrame();
		//Checking initial number of RFQ's to verify if we have successfully created New RFQ
		WebElement NumberofRowsbeforeexecution = driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/section[1]/section[1]/section[1]/main[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/table[1]/tbody[1]"));
		List<WebElement>TotalRowsList = NumberofRowsbeforeexecution.findElements(By.tagName("tr"));
		System.out.println("Total number of Rows in the table are : "+ TotalRowsList.size());
		//Creating New RFQ
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/section/section/section/main/div[2]/div/div[2]/div/a")).click();
		driver.findElement(By.cssSelector("div:nth-child(2) > .ant-btn")).click();
		driver.findElement(By.cssSelector(".ant-select-search__field > .ant-input")).click();
		driver.findElement(By.cssSelector(".ant-select-search__field > .ant-input")).sendKeys("srujan");
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".ant-select-search__field > .ant-input")).sendKeys(Keys.ENTER);
		driver.findElement(By.xpath("//tbody/tr[1]/td[1]/span[1]/label[1]/span[1]/input[1]")).click();
		driver.findElement(By.xpath("//body[1]/div[4]/div[1]/div[2]/div[1]/div[2]/div[3]/button[2]")).click();
		driver.findElement(By.xpath("//div[contains(text(),'Select User')]")).click();
		driver.findElement(By.xpath("//li[contains(text(),'srujan reddy')]")).click();
		driver.findElement(By.xpath("//body/div[@id='root']/div[1]/div[1]/section[1]/section[1]/section[1]/main[1]/main[1]/div[2]/form[1]/div[2]/div[1]/div[1]/div[3]/button[1]")).click();
		driver.findElement(By.xpath("//li[contains(text(),'Add Items from Inventory')]")).click();
		//Entering SKU 
		driver.findElement(By.xpath("//body/div[8]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/ul[1]/li[1]/div[1]/span[1]/input[1]")).sendKeys("srauto");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//body/div[8]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/ul[1]/li[1]/div[1]/span[1]/input[1]")).sendKeys(Keys.ENTER);
		driver.findElement(By.xpath("//body[1]/div[8]/div[1]/div[2]/div[1]/div[1]/div[2]/div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/table[1]/tbody[1]/tr[1]/td[2]")).click();
		Thread.sleep(3000);
		driver.findElement(By.cssSelector(".style_activatedStockRow__2EqrJ > td:nth-child(4)")).click();
		driver.findElement(By.xpath("//button[contains(.,'Ok')]")).click();
		driver.findElement(By.xpath("//body[1]/div[1]/div[1]/div[1]/section[1]/section[1]/section[1]/main[1]/main[1]/div[3]/div[1]/div[1]/button[2]")).click();
		driver.findElement(By.xpath("//body/div[@id='root']/div[1]/div[1]/section[1]/section[1]/section[1]/main[1]/main[1]/div[3]/div[1]/div[1]/button[1]")).click();
		Thread.sleep(4000);
		driver.findElement(By.xpath("//body/div[@id='root']/div[1]/div[1]/section[1]/section[1]/section[1]/main[1]/main[1]/div[3]/div[1]/div[1]/button[1]")).click();
		//Checking new RFQ created and comparing to initial number of RFQ's
		WebElement NumberofRowsafterexecution = driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/section[1]/section[1]/section[1]/main[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/table[1]/tbody[1]"));
		List<WebElement>TotalRowsListafter = NumberofRowsafterexecution.findElements(By.tagName("tr"));
		System.out.println("Total number of Rows in the table are : "+ TotalRowsListafter.size());
		Boolean ispass=TotalRowsListafter.size()>TotalRowsList.size()?true:false;
		assertTrue(ispass);
		//Closing Browser
		driver.quit();
	}
}
